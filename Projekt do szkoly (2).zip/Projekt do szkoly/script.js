document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('visitForm').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Dziękujemy! Twoja wizyta została zarejestrowana. Skontaktujemy się z Tobą w celu potwierdzenia.');
        this.reset();
    });
    
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            document.querySelector(targetId).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});